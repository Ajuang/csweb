<?php
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Silex\Application;
use Aura\Sql\ExtendedPdo;
use Aura\Sql\Profiler;
require __DIR__ . '/../src/api/app/app.php';
require_once __DIR__ . '/../src/api/app/helpers.php';

//PhpUnit test cases will run this include index.php in create application for each WebTestCase.
//declaring helper functions in this file will cause redeclaration errors.
//helper functions should be implemented in external files.

use CSPro\CSProResponse;
$app->mount('/users', new CSPro\Controllers\UserController());
$app->mount('/dictionaries', new CSPro\Controllers\DictionaryController());
$app->mount('/files', new CSPro\Controllers\FilesController());
$app->mount('/folders', new CSPro\Controllers\FoldersController());
$app->mount('/apps', new CSPro\Controllers\AppsController());

$app->error(function (\Exception $e, $code) use ($app) {
    if ($app['debug']) {
        return;
    }
	$result['code'] = $code;
    switch ($code) {
        case 404:
            $result['description']  = $e->getMessage();//'The requested page could not be found.';
            break;
        default:
            $result['description'] = 'We are sorry, but something went terribly wrong.';
    }
    $response = new CSProResponse();
    $response->setError($result['code'],'fatal_error',$result['description']);
    $response->headers->set('Content-Length', strlen($response->getContent()));
    return $response;
});

$oauthVerifyResourceRequest = function (Request $request, Application $app) {
    // ...
    //getContent becomes empty when doing verifyResourceRequest check in the before event  on PUT requests 
    //one way to avoid is to remove this check on PUT requests before events. 
    //alternative is to call the getContent  on PUT requests. If this sttops working remove the before event and figure out 
    //to authenticate the token in PUT methods  -https://forum.phalconphp.com/discussion/6422/sending-put-request-with-content-type-other-than-texthtml-fails
    //this bug is due to the call to verifyResourceRequest in  bshaefer's oauth package.
   if($request->getMethod() == 'PUT')
        $content =$request->getContent();
    
	$app['monolog']->addDebug('Authenticating User.');

	//When running phpUnit tests the global $_SERVER headers are not set.  Adding them manually here to validate token
	$app_env =  getenv('env');
	if (isset($app_env) && 'test' == $app_env)  {
		$_SERVER['HTTP_AUTHORIZATION'] =$request->headers->get('Authorization');
		$app['monolog']->addDebug('Authenticating User.' . $_SERVER['HTTP_AUTHORIZATION']);
		
	}

	if ($app['oauth'] == true && !$app['server']->verifyResourceRequest(OAuth2\Request::createFromGlobals())) {
		//$app['server']->getResponse()->send(); //send 401 response - Unauthorized;
        $response = new CSProResponse();
		$response->setError(401, 'Unauthorized', 'Unauthorized ');
        $response->headers->set('Content-Length', strlen($response->getContent()));
        return $response;
	}
	
	//check if valid schema
	$schemaValidator = new CSPro\CSProSchemaValidator($app['schemaVersion'], $app['pdo'], $app['monolog']);
	if(!$schemaValidator->isValidSchema()){
		$response = new CSProResponse();
		$response->setError(500, 'Internal Server Error', 'The database schema version does not match the version of the CSWeb code. Use /csweb/upgrade to update the database to the latest version.');
		$response->headers->set('Content-Length', strlen($response->getContent()));
		return $response;
	}
	
};

//Get the token from oauth -verb should be POST when getting a token
$app->POST('/token', function(Application $app, Request $request)
{
	// Handle a request for an OAuth2.0 Access Token and send the response to the client
	
	//When running phpUnit tests the global $_SERVER headers are not set.  Adding them manually here to get  token
	$app_env =  getenv('env');
	if (isset($app_env) && 'test' == $app_env)  {
		if (!isset($_SERVER['REQUEST_METHOD'])){
			$_SERVER['REQUEST_METHOD'] = $request->getMethod();
		}
		if (!isset($_SERVER['CONTENT_TYPE'])){
			$_SERVER['CONTENT_TYPE'] = 'application/json';
		}
		
	}

	$oauthRequest = OAuth2\Request::createFromGlobals();
	
	//When running phpUnit tests the $_POST or php.input is not set. Setting the JSON body here to get  token
	if (isset($app_env) && 'test' == $app_env)  {
		$oauthRequest->request =  json_decode($request->getContent(), true);
	}
	
	$oauthResponse = $app['server']->handleTokenRequest($oauthRequest );
	
	if ($oauthResponse->isSuccessful()) {
		// Success
		$response = new CSProResponse($oauthResponse->getResponseBody(), 
									  $oauthResponse->getStatusCode(),
									  $oauthResponse->getHttpHeaders());
	} else {
		// Translate the oauth error into CSPro error format
		$response = new CSProResponse();
		$oauthError = json_decode($oauthResponse->getResponseBody(), true);
		$response->setError($oauthResponse->getStatusCode(), 
		                    $oauthError['error'], 
							$oauthError['error_description']);
		$response->headers->add($oauthResponse->getHttpHeaders());
	}
	
	$response->headers->set('Content-Length', strlen($response->getContent()));
	return $response;

});

//flush the controller and add the before middleware
$app->flush();
$app['routes']->get('addUser')->before($oauthVerifyResourceRequest);
$app['routes']->get('getUserList')->before($oauthVerifyResourceRequest);
$app['routes']->get('getUser')->before($oauthVerifyResourceRequest);
$app['routes']->get('updateUser')->before($oauthVerifyResourceRequest);
$app['routes']->get('deleteUser')->before($oauthVerifyResourceRequest);


$app['routes']->get('getDictionaryList')->before($oauthVerifyResourceRequest);
$app['routes']->get('addDictionary')->before($oauthVerifyResourceRequest);
$app['routes']->get('getDictionary')->before($oauthVerifyResourceRequest);
$app['routes']->get('deleteDictionary')->before($oauthVerifyResourceRequest);

$app['routes']->get('getSyncHistory')->before($oauthVerifyResourceRequest);
$app['routes']->get('syncCases')->before($oauthVerifyResourceRequest);

$app['routes']->get('getCases')->before($oauthVerifyResourceRequest);
$app['routes']->get('addOrUpdateCases')->before($oauthVerifyResourceRequest);
$app['routes']->get('getCase')->before($oauthVerifyResourceRequest);
$app['routes']->get('updateCase')->before($oauthVerifyResourceRequest);
$app['routes']->get('deleteCase')->before($oauthVerifyResourceRequest);

$app['routes']->get('getFileInfo')->assert('filePath', '.*(?<!content)$')->before($oauthVerifyResourceRequest);
$app['routes']->get('getFileContent')->assert('filePath', '.+')->before($oauthVerifyResourceRequest);
$app['routes']->get('updateFileContent')->assert('filePath', '.+')->before($oauthVerifyResourceRequest);
$app['routes']->get('addFileContent')->assert('filePath', '.+')->before($oauthVerifyResourceRequest);

$app['routes']->get('getDirectoryListing')->assert('folderPath', '.*')->before($oauthVerifyResourceRequest);

$app['routes']->get('getApps')->before($oauthVerifyResourceRequest);
$app['routes']->get('getApp')->before($oauthVerifyResourceRequest);
$app['routes']->get('updateApp')->before($oauthVerifyResourceRequest);
$app['routes']->get('deleteApp')->before($oauthVerifyResourceRequest);

//Get the server information
$app->GET('/server', function(Application $app, Request $request)
{
	$result['deviceId'] = $app['deviceId']; //server name
	$result['apiVersion'] = $app['apiVersion'] ;
    $response = new CSProResponse(json_encode($result));
    //remove quotes around quoted numeric values
    $response->setContent(preg_replace('/"(-?\d+\.?\d*)"/', '$1', $response->getContent()));
    $response->headers->set('Content-Length', strlen($response->getContent()));
	//echo ' total time'.(microtime(true)-$app['start']);
    return $response;
})->before($oauthVerifyResourceRequest);


if (isset($app_env) && 'test' == $app_env) { //to support phpUnit WebTestCase createApplication
    return $app;
}
else
    $app->run();
