<?php

namespace CSPro\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;
use CSPro\CSProResponse;

class UserController implements ControllerProviderInterface {
	public function connect(Application $app) {
		// creates a new controller based on the default route
		$controllers = $app ['controllers_factory'];
		$controllers->post ( '/', 'CSPro\Controllers\UserController::addUser' )->bind ( 'addUser' );
		$controllers->get ( '/', 'CSPro\Controllers\UserController::getUserList' )->bind ( 'getUserList' );
		$controllers->get ( '/{username}', 'CSPro\Controllers\UserController::getUser' )->bind ( 'getUser' );
		$controllers->put ( '/{username}', 'CSPro\Controllers\UserController::updateUser' )->bind ( 'updateUser' );
		$controllers->delete ( '/{username}', 'CSPro\Controllers\UserController::deleteUser' )->bind ( 'deleteUser' );
		
		// check if you can pass a funcition to the controller for before action
		return $controllers;
	}
	function addUser(Application $app, Request $request) {
		$params = array ();
		$content = $request->getContent ();
		$response = new CSProResponse ();
		if (empty ( $content )) {
			$response->setError ( 400, 'user_invalid_request', 'Invalid request. Missing JSON content.' );
			return $response;
		} else {
			$uri = '#/definitions/User';
			validateEncodedJSON ( $app, $content, $uri );
			$params = json_decode ( $content, true ); // 2nd param to get as array
			if (! isValidUser ( $params )) {
				$response->setError ( 400, 'user_invalid', 'Invalid User Supplied. User attributes cannot be blank or invalid.' );
				return $response;
			}
		}
		try {
		$pdo = $app ['pdo'];
		$stm = 'SELECT username  FROM cspro_users WHERE username = :uname;';
		$username = strtolower ( $params ['username'] );
		$bind = array (
				'uname' => array (
						'uname' => $username 
				) 
		);
		if ($pdo->fetchValue ( $stm, $bind )) {
			$response->setError ( 405, 'user_name_exists', 'Username already in use' );
			return $response;
		}
		
		if (! isset ( $params ['role'] )) {
			$params ['role'] = 1; // Standard User
		}
		$stmt = $pdo->prepare ( "INSERT INTO cspro_users (username, password, first_name, last_name, role)
								VALUES (:uname,:pass,:fname,:lname, :role)" );
		$stmt->bindParam ( ':uname', $username );
		$passwordHash = password_hash ( $params ['password'], PASSWORD_DEFAULT );
		$stmt->bindParam ( ':pass', $passwordHash );
		$stmt->bindParam ( ':fname', $params ['firstName'] );
		$stmt->bindParam ( ':lname', $params ['lastName'] );
		$stmt->bindParam ( ':role', $params ['role'] );
		$stmt->execute ();
		}catch ( \Exception $e ) {
			$app ['monolog']->addError('Failed adding user: '. $username, array("context" => (string)$e));
			$response = new CSProResponse();
			$response->setError(500, 'user_add_error', 'Failed adding user');
		}
		$response = new CSProResponse ( json_encode ( array (
				"code" => 200,
				"description" => "Success" 
		) ), 200 );
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;
	}
	// get users
	function getUserList(Application $app, Request $request) {
		try {
			$pdo = $app ['pdo'];
			$stm = 'SELECT username, first_name as firstName, last_name as lastName, role as role
				FROM cspro_users ORDER BY username';
			$result = $pdo->fetchAll ( $stm );
			$response = new CSProResponse ( json_encode ( $result ) );
		} catch ( \Exception $e ) {
			$app ['monolog']->addError('Failed getting user list', array("context" => (string)$e));
			$result ['code'] = 500;
			$result ['description'] = 'Failed getting user list';
			$response = new CSProResponse ();
			$response->setError($result ['code'],'users_get_error',$result ['description']);
		}
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;
	}
	function getUser(Application $app, Request $request, $username) {
		$pdo = $app ['pdo'];
		try {
			$stm = 'SELECT username, first_name as firstName, last_name as lastName, role as role
				FROM cspro_users where username = :uname';
			$bind = array (
					'uname' => array (
							'uname' => $username 
					) 
			);
			$result = $pdo->fetchAll ( $stm, $bind );
			if (! $result) {
				$response = new CSProResponse ();
				$response->setError ( 404, 'user_not_found', 'User not found' );
				return $response;
			} else {
				$resultUser = $result [0];
				$response = new CSProResponse ( json_encode ( $resultUser ) );
			}
		} catch ( \Exception $e ) {
			$app ['monolog']->addError('Failed getting user: ' . username, array("context" => (string)$e));
			$response = new CSProResponse();
			$response->setError(500, 'user_get_error', 'Failed getting user');
		}
		
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;
	}
	
	// Update User
	function updateUser(Application $app, Request $request, $username) {
		$params = array ();
		$content = $request->getContent ();
		$response = new CSProResponse ();
		
		if (empty ( $content )) {
			$response->setError ( 400, null, 'Missing JSON content in the request' );
			return $response;
		} else {
			$uri = '#/definitions/User';
			validateEncodedJSON ( $app, $content, $uri );
			$params = json_decode ( $content, true ); // 2nd param to get as array
			if (! isValidUser ( $params, false )) {
				$response->setError ( 400, 'invalid_user', 'Invalid User Supplied. User attributes cannot be blank or invalid.' );
				return $response;
			}
		}
		try {
			$pdo = $app ['pdo'];
			$stm = 'SELECT username , role  FROM cspro_users WHERE username = :uname;';
			$bind = array (
					'uname' => array (
							'uname' => $username 
					) 
			);
			$result = $pdo->fetchAll ( $stm, $bind );
			if (count ( $result ) == 0) {
				$response->setError ( 404, 'user_not_found', 'User not found' );
				return $response;
			}
			$userrole = isset ( $params ['role'] ) ? $params ['role'] : $result ['role'];
			if (! empty ( $params ['password'] )) {
				$stmt = $pdo->prepare ( "UPDATE cspro_users
	                               SET username=:uname, password=:pass, first_name=:fname, last_name=:lname, role=:role
	                               WHERE username=:origuname" );
			} else {
				$stmt = $pdo->prepare ( "UPDATE cspro_users
	                               SET username=:uname, first_name=:fname, last_name=:lname, role=:role
	                               WHERE username=:origuname" );
			}
			$stmt->bindParam ( ':uname', $params ['username'] );
			if (! empty ( $params ['password'] )) {
				$passwordHash = password_hash ( $params ['password'], PASSWORD_DEFAULT );
				$stmt->bindParam ( ':pass', $passwordHash );
			}
			$stmt->bindParam ( ':fname', $params ['firstName'] );
			$stmt->bindParam ( ':lname', $params ['lastName'] );
			$stmt->bindParam ( ':origuname', $username );
			$stmt->bindParam ( ':role', $userrole );
			$stmt->execute ();
			$response = new CSProResponse ( json_encode ( array (
					"code" => 200,
					"description" => 'The user ' . $username . ' was successfully updated.' 
			) ), 200 );
		} catch ( \Exception $e ) {
			$app ['monolog']->addError('Failed updating user: ' . username, array("context" => (string)$e));
			$result ['code'] = 500;
			$result ['description'] = 'Failed updating user';
			$response = new CSProResponse ();
			$response->setError($result ['code'],'user_update_failed',$result ['description']);
		}
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;
	}
	
	// Delete User
	function deleteUser(Application $app, Request $request, $username) {
		$pdo = $app ['pdo'];
		try {
			$pdo->beginTransaction ();
			$stm = 'DELETE FROM cspro_users WHERE username = :username';
			$bind = array (
					'username' => array (
							'username' => $username 
					) 
			);
			$row_count = $pdo->fetchAffected ( $stm, $bind );
			
			if ($row_count == 1) {
				$pdo->commit ();
				$result ['code'] = 200;
				$result ['description'] = 'The user ' . $username . ' was successfully deleted.';
				$response = new CSProResponse ( json_encode ( $result ) );
				$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
			} else {
				$result ['code'] = 404;
				$result ['description'] = 'The username ' . $username . ' was not found.';
				$response = new CSProResponse ();
				$response->setError($result ['code'],'user_delete_failed',$result ['description']);
			}
		} catch ( \Exception $e ) {
			$pdo->rollBack ();
			$app ['monolog']->addError('Failed deleting user: ' . username, array("context" => (string)$e));
			$result ['code'] = 404;
			$result ['description'] = 'The user ' . $username . ' was not deleted.';
			$response = new CSProResponse ();
			$response->setError($result ['code'],'user_delete_failed',$result ['description']);
		}
		
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;
	}
}
