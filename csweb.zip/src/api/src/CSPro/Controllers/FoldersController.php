<?php
namespace CSPro\Controllers;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;
use CSPro\CSProResponse;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use CSPro\FileManager;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class FoldersController implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];
		$controllers->get('/{folderPath}', 'CSPro\Controllers\FoldersController::getDirectoryListing')->bind('getDirectoryListing');
		//check if you can pass a function  to the controller for before action
        return $controllers;
    }

	function getDirectoryListing(Application $app, Request $request, $folderPath)
	{
		$fileManager = new FileManager();
		$fileManager->rootFolder = $app['files_folder'];
		$dirList = $fileManager->getDirectoryListing($folderPath);
		$response  = null;
		if(is_dir($fileManager->rootFolder . DIRECTORY_SEPARATOR . $folderPath)) {
			$response = new CSProResponse(json_encode($dirList));
		}
		else {
			$response = new CSProResponse();
			$response->setError(404, 'directory_not_found', 'Directory not found');
		}
		$response->headers->set('Content-Length', strlen($response->getContent()));
		return $response;
	}

}