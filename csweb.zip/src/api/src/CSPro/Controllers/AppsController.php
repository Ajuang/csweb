<?php

namespace CSPro\Controllers;

use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;
use CSPro\CSProResponse;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class AppsController implements ControllerProviderInterface {
	private $appsDir;
	
	public function connect(Application $app) {
		// creates a new controller based on the default route
		$controllers = $app ['controllers_factory'];
		$controllers->get ( '/', 'CSPro\Controllers\AppsController::getApps' )->bind ( 'getApps' );
		$controllers->get ( '/{appName}', 'CSPro\Controllers\AppsController::getApp' )->bind ( 'getApp' );
		$controllers->put ( '/{appName}', 'CSPro\Controllers\AppsController::updateApp' )->bind ( 'updateApp' );
		$controllers->delete ( '/{appName}', 'CSPro\Controllers\AppsController::deleteApp' )->bind ( 'deleteApp' );
			
		return $controllers;
	}
	
	function getApps(Application $app, Request $request) {
		// Download list of apps in JSON from cspro_apps table
		
		$pdo = $app ['pdo'];

		$stm = 'SELECT name, description, build_time as buildTime, version 
				FROM cspro_apps';
		$result = $pdo->fetchAll ( $stm );
		
		// Generate app spec json from query result
		foreach ( $result as &$row ) {
			
			// Same in every file
			$row['FileType'] = 'Application Deployment Specification';

			// Convert build time to RFC3339
			$buildTimeUtc = \DateTime::createFromFormat('Y-m-d H:i:s', $row['buildTime'], new \DateTimeZone("UTC"));
			$row ['buildTime'] = $buildTimeUtc->format(\DateTime::RFC3339);
		}
		unset ( $row );
		$response = new CSProResponse ( json_encode ( $result ) );
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		
		return $response;
	}
	
	function updateApp(Application $app, Request $request, $appName) 
	{
		// Upload application package
		// Package is a CSPro application bundle which
		// is just a zip archive. This file is copied to the apps
		// directory. The zip archive contains a deployment
		// spec file named package.csds. Extract this file and read
		// the parameters from it and add them to cspro_apps table
		// in database.
				
		$contentLength = $request->headers->get('Content-Length');
		$content = $request->getContent();
		if (isset($contentLength) && $contentLength != strlen($content)) {
			$app ['monolog']->addError( 'Invalid content length on app package' . $appName);
			$response = new CSProResponse();
			$response->setError(403, 'app_upload_failed', 'Unable to write app package. Content length header does not match uploaded file contents.');
			return $response;
		}

		// Make sure apps directory exists.
		$appsDir = $app['files_folder'] . DIRECTORY_SEPARATOR . 'apps';
		if(!is_dir($appsDir)){
			
			$app ['monolog']->addInfo('Creating apps directory' . $appsDir);
			if (!mkdir($appsDir)) {
				$app ['monolog']->addError( 'Unable to create apps directory' . $appsDir);
				$response = new CSProResponse();
				$response->setError(403, 'app_upload_failed', 'Unable to create apps directory '.$appsDir);
				return $response;
			}
		}

		// Save the package zip file to a temp file in apps directory
		// Later we will rename to give it name of app but need to make
		// sure it is valid first
		$filePath = @tempnam($appsDir, 'tmpApp');
		if ($filePath === FALSE)
		{
			$app ['monolog']->addError( 'Internal error creating temp file for unzip' . $filePath);
			$response = new CSProResponse();
			$response->setError(500, 'app_upload_failed', 'Error creating temp file');
			return $response;
		}

		if(@file_put_contents($filePath, $content) === FALSE) 
		{
			@unlink($filePath);
			$app ['monolog']->addError( 'Internal error writing app package zip file' . $filePath);
			$response = new CSProResponse();
			$response->setError(500, 'app_upload_failed', 'Error writing file');
			return $response;
		}

		// Extract the spec file from zip archive
		if (class_exists('ZipArchive')) {
			$zip = new \ZipArchive;
		} else {
                        @unlink($filePath);
                        $app ['monolog']->addError('Failed to load class ZipArchive. Ensure that zip support in PHP is enabled');
                        $response = new CSProResponse();
                        $response->setError(500, 'app_upload_failed', 'Failed to load class ZipArchive. Ensure that zip support in PHP is enabled');
                        return $response;
		}
		$openResult = $zip->open($filePath);
		if ($zip->open($filePath) !== TRUE) {
			@unlink($filePath);
			$app ['monolog']->addError( 'Failed to open app package zip file ' . $filePath);
			$response = new CSProResponse();
			$response->setError(500, 'app_upload_failed', 'Failed to open app package zip file '. $appName);
			return $response;
		}
		
		$appSpec = $zip->getFromName('package.csds');
		$zip->close();
		
		// Validate JSON spec file
		$uri = '#/definitions/ApplicationDeploymentSpecification';
		validateEncodedJSON ( $app, $appSpec, $uri );
		$params = json_decode ( $appSpec, true ); // 2nd param to get as array
		if (empty($params['name']) || empty($params['buildTime']) || empty ($params['version'])) {
			@unlink($filePath);
			$app ['monolog']->addError( 'Invalid app spec - missing required fields ' . $filePath);
			$response = new CSProResponse();
			$response->setError ( 400, 'invalid_app_specification', 'Invalid application specification supplied. Name, Version and BuildTime are required.' );
			return $response;
		}

		if ($params['name'] != $appName){
			@unlink($filePath);
			$app ['monolog']->addError( 'Invalid app spec - Name does not match name in url');
			$response = new CSProResponse();
			$response->setError ( 400, 'invalid_app_specification', 'Name does not match name in url.' );
			return $response;			
		}
	
		$invalidFileChars = array('\\', '/', ':', '*', '?', '"', '<', '>', '|'); 
		$params['path'] = 'apps' . DIRECTORY_SEPARATOR . str_replace($invalidFileChars, '_', $appName) . '.zip';

		try {
			// Add to/update cspro_apps table in database

			$buildTime = date_create($params['buildTime'])->format('Y-m-d H:i:s');

			$pdo = $app['pdo'];
			$stmt = $pdo->prepare('INSERT INTO cspro_apps (name, description, build_time, path, version)
				VALUES (:name, :description, :build_time, :path, :version)
				ON DUPLICATE KEY UPDATE name=:name, description=:description, build_time=:build_time, path=:path, version=:version');
			$stmt->bindParam ( ':name', $params ['name'] );
			$stmt->bindParam ( ':description', $params ['description'] );
			$stmt->bindParam ( ':build_time', $buildTime);
			$stmt->bindParam ( ':path', $params['path'] );
			$stmt->bindParam ( ':version', $params ['version'] );
			$stmt->execute ();
			
			// Rename zip file
			if (@rename($filePath, $app['files_folder'] . DIRECTORY_SEPARATOR . $params['path']) === FALSE)
			{
				@unlink($filePath);
				$app ['monolog']->addError( 'Failed to rename app package zip file ' . $filePath);
				$response = new CSProResponse();
				$response->setError(500, 'app_upload_failed', 'Failed to rename app package zip file '. $appName);
				return $response;								
			}
			
			$response = new CSProResponse ( json_encode ( array (
					"code" => 200,
					"description" => 'The application ' . $appName . ' was successfully updated.' 
			) ), 200 );
			
		} catch ( \Exception $e ) {
			@unlink($filePath);
			$app ['monolog']->addError('Failed updating app: ' . $appName, array("context" => (string)$e));
			$response = new CSProResponse();
			$response->setError ( 500, 'app_update_failed', 'Failed to update application in database.' );
			return $response;
		}
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;
	}

	function getApp(Application $app, Request $request, $appName)
	{
		$pdo = $app ['pdo'];
		$stm = 'SELECT path FROM cspro_apps WHERE name = :appName;';
		$bind = array (
				'appName' => array (
						'appName' => $appName 
				) 
		);
		
		$appPath = $pdo->fetchValue ( $stm, $bind );
		if ($appPath == false) {
			$response = new CSProResponse();
			$response->setError ( 404, 'app_not_found', 'Application ' . $appName . ' not found' );
			$app ['monolog']->addError('Failed downloading app: ' . $appName . '. Not found in database.');
			return $response;
		}
		
		$appPath = $app['files_folder'] . DIRECTORY_SEPARATOR . $appPath;
		if (!file_exists($appPath))
		{
			$response = new CSProResponse();
			$response->setError ( 404, 'app_not_found', 'Application ' . $appName . ' not found' );
			$app ['monolog']->addError('Failed downloading app: ' . $appName . '. File ' . $appPath . ' not found.');
			return $response;			
		}
		
		$response= new BinaryFileResponse($appPath);
		$response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, basename($appPath));

		return $response;
	}
	
	function deleteApp(Application $app, Request $request, $appName) {
		$pdo = $app['pdo'];
		
		try {
			$stm = 'SELECT path FROM cspro_apps WHERE name = :appName;';
			$bind = array (
					'appName' => array (
							'appName' => $appName 
					) 
			);
			
			$appPath = $pdo->fetchValue ( $stm, $bind );
			if ($appPath == false) {
				$response = new CSProResponse();
				$response->setError ( 404, 'app_not_found', 'Application ' . $appName . ' not found' );
				$app ['monolog']->addError('Failed deleting app: ' . $appName . '. Not found in database.');
				return $response;
			}
			
			$appPath = $app['files_folder'] . DIRECTORY_SEPARATOR . $appPath;
			@unlink($appPath);
			
			$stm = 'DELETE FROM cspro_apps WHERE name = :appName';
			$bind = array (
					'appName' => array (
							'appName' => $appName 
					) 
			);
			$row_count = $pdo->fetchAffected ( $stm, $bind );
			
			if ($row_count == 1) {
				$response = new CSProResponse ( json_encode ( array (
						"code" => 200,
						"description" => 'The application ' . $appName . ' was successfully deleted.' 
				) ), 200 );
			} else {
				$response = new CSProResponse ();
				$response->setError ( 404, 'app_delete_error', 'Application ' . $appName . ' not found ' );
				$app ['monolog']->addError('Failed deleting app: ' . $appName);
			}
			
		} catch ( \Exception $e ) {
			$app ['monolog']->addError ( 'Failed deleting app: ' . $appName, array("context" => (string)$e));
			$response = new CSProResponse ();
			$response->setError ( 500, 'app_delete_error', 'Failed deleting dictionary' );
		}
		
		$response->headers->set ( 'Content-Length', strlen ( $response->getContent () ) );
		return $response;	
	}
}
