<?php
use CSPro\VectorClock;
use CSPro\SyncHistoryEntry;
use CSPro\CSProResponse;
use CSPro\Dictionary;
use CSPro\Data;

// TODO: refactor code to Util in CSPro namespace
function dictionaryExists($app, $dictName) {
	$pdo = $app ['pdo'];
	$stm = 'SELECT id  FROM cspro_dictionaries WHERE dictionary_name = :dictName;';
	$bind = array (
			'dictName' => array (
					'dictName' => $dictName 
			) 
	);
	return $pdo->fetchValue ( $stm, $bind );
}
function checkDictionaryExists($app, $dictName) {
	if (dictionaryExists ( $app, $dictName ) == false) {
		$app->abort ( 404, "Dictionary {$dictName} does not exist." );
	}
}
function loadDictionary($app, $dictName) {
	if(extension_loaded('apcu') && ini_get('apc.enabled')){
		$bFound = false;
    	$dict  = apc_fetch($dictName, $bFound);
    	if($bFound == true)
    		return $dict;
	}
	$pdo = $app ['pdo'];
	$stm = 'SELECT dictionary_full_content FROM cspro_dictionaries WHERE dictionary_name = :dictName;';
	$bind = array (
			'dictName' => array (
					'dictName' => $dictName 
			) 
	);
	$dictText = $pdo->fetchValue ( $stm, $bind );
	if ($dictText == false) {
		$app->abort ( 404, "Dictionary {$dictName} does not exist." );
	}
	
	$parser = new \CSPro\Dictionary\Parser ();
	try {
		$dict =  $parser->parseDictionary ( $dictText );
		if(extension_loaded('apcu') && ini_get('apc.enabled')){
			 apc_store($dictName, $dict);
		}
		return $dict;
	} catch ( \Exception $e ) {
		$app ['monolog']->addError('Failed loading dictionary: ' . $dictName, array("context" => (string)$e));
		$app->abort ( 400, 'dictionary_invalid', $e->getMessage () );
	}
}
function generateItemSql($item, $hasSubItems) {
	$sql = '`id_' . $item->getName () . '` ';
	if ($item->getDataType () == 'Alpha' || $hasSubItems) {
		$len = intval ( $item->getLength () );
		$sql .= "CHAR($len) COLLATE utf8mb4_unicode_ci NULL,";
	} else {
		$decimalChars = $item->getDecimalPlaces ();
		if ($decimalChars > 0) {
			$intChars = $item->getLength () - $decimalChars;
			if ($item->getDecimalChar ())
				-- $intChars;
			$sql .= "DECIMAL($intChars,$decimalChars) NULL,";
		} else {
			$sql .= 'INTEGER NULL,';
		}
	}
	return $sql . "\n";
}
function createDictionary($app, $dict, $dictContent, &$csproResponse) {
	
	$dictName = $dict->getName ();
	$dictLabel = $dict->getLabel ();
	
	if (dictionaryExists ( $app, $dictName )) {
		$csproResponse->setError ( 405, 'dictionary_exists', "Dictionary {$dictName} already exists." );
		$csproResponse->setStatusCode ( 405 );
		return;
	}
	$pdo = $app ['pdo'];
	
	// Make sure dict name contains only valid chars (letters, numbers and _)
	// This matches CSPro valid names and protects against SQL injection.
	// Note that PDO does not support using a prepared statement with table name as
	// parameter.
	if (! preg_match ( '/\A[A-Z0-9_]*\z/', $dictName )) {
		$csproResponse->setError ( 400, 'dictionary_name_invalid', "{$dictName} is not a valid dictionary name." );
		$csproResponse->setStatusCode ( 400 );
		return;
	}
	
	$sql = <<<EOT
	CREATE TABLE IF NOT EXISTS `$dictName` (
	`guid` binary(16) NOT NULL,
	`caseids` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
	`label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
	`questionnaire` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
	`revision` int(11) unsigned NOT NULL,
	`deleted` tinyint(1) unsigned NOT NULL DEFAULT '0',
	`verified` tinyint(1) unsigned NOT NULL DEFAULT '0',
    `clock` text COLLATE utf8mb4_unicode_ci NOT NULL,
	`modified_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	`created_time` timestamp DEFAULT '1971-01-01 00:00:00',
	partial_save_mode varchar(6) NULL,
	partial_save_field_name varchar(255) COLLATE utf8mb4_unicode_ci NULL,
	partial_save_level_key varchar(255) COLLATE utf8mb4_unicode_ci NULL,
	partial_save_record_occurrence SMALLINT NULL,
	partial_save_item_occurrence SMALLINT NULL,
	partial_save_subitem_occurrence SMALLINT NULL,
EOT;
	
	// Add level one id-items
	$levelOneIds = $dict->getLevels () [0]->getIdItems ();
	foreach ( $levelOneIds as $idItem ) {
		$sql .= generateItemSql ( $idItem, false );
	}
	
	$trigName = 'tr_'.$dictName;
	$sql .= <<<EOT
	PRIMARY KEY (`guid`),
  	KEY `revision` (`revision`),
  	KEY `caseids` (`caseids`),
  	KEY `deleted` (`deleted`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
	CREATE TRIGGER  $trigName BEFORE INSERT ON  $dictName FOR EACH ROW SET NEW.`created_time` = CURRENT_TIMESTAMP;
EOT;
	$pdo->exec ( $sql );
	
	$stmt = $pdo->prepare ( "INSERT INTO cspro_dictionaries (`dictionary_name`,
								`dictionary_label`, `dictionary_full_content`) VALUES (:name,:label,:content)" );
	$stmt->bindParam ( ':name', $dictName );
	$stmt->bindParam ( ':label', $dictLabel );
	$stmt->bindParam ( ':content', $dictContent );
	$stmt->execute ();
	
	createDictionaryNotes ( $app, $dictName, $csproResponse );
	if ($csproResponse->getStatusCode () != 200) {
		$app ['monolog']->addDebug ( 'createDictionaryNotes: getStatusCode.' . $csproResponse->getStatusCode () );
		return $csproResponse; // failed to create notes.
	}
	
	$csproResponse = $csproResponse->setContent ( json_encode ( array (
			"code" => 200,
			"description" => 'Success' 
	) ) );
	$csproResponse->setStatusCode ( 200 );
}
function createDictionaryNotes($app, $dictName, &$csproResponse) {
	$notesTableName = $dictName . '_notes';
	// check if the notes table if it does not exist
	$sql = <<<EOT
	CREATE TABLE IF NOT EXISTS `$notesTableName` (
	`id` SERIAL PRIMARY KEY ,
	`case_guid` binary(16)  NOT NULL,
	`operator_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
	`field_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
	`level_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
	`record_occurrence` SMALLINT NOT NULL,
	`item_occurrence`  SMALLINT NOT NULL,
    `subitem_occurrence` SMALLINT NOT NULL,
	`content` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
	`modified_time` datetime NOT NULL,
	`created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	FOREIGN KEY (`case_guid`)
        REFERENCES `$dictName`(`guid`)
		ON DELETE CASCADE
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
EOT;
	$pdo = $app ['pdo'];
	
	try {
		$pdo->exec ( $sql );
	} catch ( \Exception $e ) {
		$app ['monolog']->addError('Failed creating dictionary notes: ' . $notesTableName, array("context" => (string)$e));
		$csproResponse->setError ( 405, 'notes_table_createfail', $e->getMessage () );
	}
}
function updateExistingDictionary($app, $dict, $dictContent, &$csproResponse) {

	$dictName = $dict->getName();
	$dictLabel = $dict->getLabel();
	try {
		$pdo = $app ['pdo'];
		
		// Update dictionaries table with new label and content
		$stmt = $pdo->prepare ( "UPDATE cspro_dictionaries SET `dictionary_label`=:label, `dictionary_full_content`=:content WHERE `dictionary_name`=:name" );
		$stmt->bindParam ( ':name', $dictName );
		$stmt->bindParam ( ':label', $dictLabel );
		$stmt->bindParam ( ':content', $dictContent );
		$stmt->execute ();
		
		// Check for differences in id columns
		$idcols = $pdo->fetchAll("SHOW COLUMNS FROM `{$dictName}`LIKE 'id_%'");
		$levelOneIds = $dict->getLevels()[0]->getIdItems();

		function columnMatchesId($col, $id)
		{
			if ($col['Field'] !== 'id_' . $id->getName())
				return false;
			
			if (!preg_match("/^(int|char)\((\d*)\)$/i", $col['Type'], $matches))
				return false;
			
			$colType = $matches[1];
			$colLen = $matches[2];
			
			if ($id->getDataType() == 'Alpha') {
				return $colType == 'char' && $colLen == $id->getLength();
			} else {
				return $colType == 'int';
			}
		}
				
		// Id items in dictionary not in database table
		$missingFromTable = array_filter($levelOneIds, function ($i) use($idcols) { return empty(array_filter($idcols, function ($c) use($i) { return columnMatchesId($c, $i);})); });
		if (!empty($missingFromTable))
		{
			$missingNames = implode(', ', array_map(function ($i) {return $i->getName();}, $missingFromTable));
			$app['monolog']->addError("Failed to update dictionary: Id items missing from existing table $missingNames");
			$csproResponse->setError ( 400, 'dictionary_changed', "Id items do not match existing data ($missingNames). Download and reformat existing data to match the new dictionary. Then delete existing data on the server and replace it with the reformatted data" );
			$csproResponse->setStatusCode ( 400 );
			return;		
		}
		
		// Id items in database table not in dictionary
		$missingFromDict = array_filter($idcols, function ($c) use($levelOneIds) { return empty(array_filter($levelOneIds, function ($i) use($c) {return columnMatchesId($c, $i);})); });
		if (!empty($missingFromDict))
		{
			$missingNames = implode(', ', array_map(function ($c) {return $c['Field'];}, $missingFromDict));
			$app['monolog']->addError("Failed to update dictionary: Id items missing from dictionary $missingNames");
			$csproResponse->setError ( 400, 'dictionary_changed', "Id items do not match existing data ($missingNames). Download and reformat existing data to match the new dictionary. Then delete existing data on the server and replace it with the reformatted data" );
			$csproResponse->setStatusCode ( 400 );
			return;		
		}

		$csproResponse = $csproResponse->setContent ( json_encode ( array (
				"code" => 200,
				"description" => 'Success' 
		) ) );
		$csproResponse->setStatusCode ( 200 );
	} catch ( \Exception $e ) {
		$app ['monolog']->addError('Failed to update dictionary: ' . $dictName, array("context" => (string)$e));
		$csproResponse->setError ( 500, 'dictionary_update_fail', $e->getMessage () );
	}
}

function getLastSyncForDevice($pdo, $dictName, $device) {
	try {
		$stm = 'SELECT revision AS revisionNumber, device, dictionary_name AS dictionary, universe, direction, cspro_sync_history.created_time as dateTime from cspro_sync_history JOIN cspro_dictionaries ON dictionary_id = cspro_dictionaries.id WHERE device=:device AND dictionary_name = :dictName ORDER BY revision DESC LIMIT 1';
		$bind = array (
				'device' => array (
						'device' => $device 
				),
				'dictName' => array (
						'dictName' => $dictName 
				) 
		);
		return $pdo->fetchObject ( $stm, $bind, 'CSPro\SyncHistoryEntry' );
	} catch ( \Exception $e ) {
		throw new \Exception ( 'Failed in getLastSyncForDevice ' . $dictName, 0,  $e );
	}
}
function getSyncHistoryByRevisionNumber($pdo, $dictName, $revisionNumber) {
	try {
		$stm = 'SELECT revision AS revisionNumber, device, dictionary_name AS dictionary, universe, direction, cspro_sync_history.created_time as dateTime from cspro_sync_history JOIN cspro_dictionaries ON dictionary_id = cspro_dictionaries.id WHERE revision = :revisionNumber AND dictionary_name = :dictName';
		$bind = array (
				'revisionNumber' => array (
						'revisionNumber' => $revisionNumber 
				),
				'dictName' => array (
						'dictName' => $dictName 
				) 
		);
		return $pdo->fetchObject ( $stm, $bind, 'CSPro\SyncHistoryEntry' );
	} catch ( \Exception $e ) {
		throw new \Exception ( 'Failed in getSyncHistoryByRevisionNumber ' . $dictName, 0, $e );
	}
}


// is universe more restrictive Or same as the previous revision
function isUniverseMoreRestrictiveOrSame($currentUniverse, $lastRevisionUniverse) {
	// if the current universe is a sub string of last revision universe, they are not the same
	if ($currentUniverse === $lastRevisionUniverse) {
		return true;
	} else {
		return (strlen ( $currentUniverse ) >= strlen ( $lastRevisionUniverse )) && substr ( $currentUniverse, 0, strlen ( $lastRevisionUniverse ) ) === $lastRevisionUniverse;
	}
}

// Add a new sync history entry to database and return the revision number
function addSyncHistoryEntry($app, $deviceId, $dictName, $direction, $universe = "") {
	$pdo = $app ['pdo'];
	//SELECT dictionary ID 
	$dictId = dictionaryExists($app, $dictName);
	if($dictId == false){
		$app->abort ( 404, "Dictionary {$dictName} does not exist." );
	}
	// insert a row into the sync history with the new version
	$stm = 'INSERT INTO cspro_sync_history (`device` , `dictionary_id`, `direction`, `universe`)
			 VALUES (:deviceId,	:dictionary_id, :direction, :universe)';
	$bind = array (
			'deviceId' => array (
					'deviceId' => $deviceId 
			),
			'dictName' => array (
					'dictName' => $dictName 
			),
			'universe' => array (
					'universe' => $universe 
			),
			'direction' => array (
					'direction' => $direction 
			),
			'dictionary_id' => array (
					'dictionary_id' => $dictId
			)
	);
	try {
		$pdo->perform ( $stm, $bind);
		$lastRevisionId = $pdo->lastInsertId ();
		
		return $lastRevisionId;
	} catch ( \Exception $e ) {
		$pdo->rollBack ();
		throw new \Exception ( 'Failed to addSyncHistoryEntry ' . $dictName, 0, $e );
	}
}


//Delete Sync history entry
function deleteSyncHistoryEntry($app, $revision) {
	$pdo = $app ['pdo'];
	
	// delete entry in sync history for the revision
	$stm = $stm = 'DELETE FROM `cspro_sync_history` WHERE revision=:revision';
	$bind = array (
			'revision' => array (
					'revision' => $revision
			)
	);
	
	$deletedSyncHistoryCount = $pdo->fetchAffected ( $stm, $bind );
	$app ['monolog']->addDebug ( 'Deleted # ' . $deletedSyncHistoryCount . ' Sync History Entry revision: ' . $revision);
	return $deletedSyncHistoryCount;
}

// Select all the cases sent by the client that exist on the server
function getLocalServerCaseList($app, $dictName, $caseList) {
	if (count ( $caseList ) == 0)
		return null;
	
	$pdo = $app ['pdo'];
	try {
		checkDictionaryExists ( $app, $dictName );
		// Select all the cases sent by the client that exist on the server
		$stm = 'SELECT  LCASE(CONCAT_WS("-", LEFT(HEX(guid), 8), MID(HEX(guid), 9,4), MID(HEX(guid), 13,4), MID(HEX(guid), 17,4), RIGHT(HEX(guid), 12))) as id,
			clock
			FROM ' . $dictName;
		$insertData = array ();
		$ids = array ();
		$strWhere = '';
		$n = 1;
		foreach ( $caseList as $row ) {
			$insertData [] = 'UNHEX(REPLACE(:guid' . $n . ',"-",""))';
			$ids ['guid' . $n] = $row ['id'];
			$n ++;
		}
		// do bind values for the where condition
		if (count ( $insertData ) > 0) {
			$inQuery = implode ( ',', $insertData );
			$stm .= ' WHERE `guid` IN (' . $inQuery . ');';
		}
		
		$stmt = $pdo->prepare ( $stm );
		
		$stmt->execute ( $ids );
		$result = $stmt->fetchAll ();
		
		$localServerCases = array ();
		foreach ( $result as $row ) {
			$localServerCases [$row ['id']] = $row;
		}
		return $localServerCases;
	} catch ( \Exception $e ) {
		throw new \Exception ( 'Failed in getLocalServerCaseList ' . $dictName, 0,  $e );
	}
}
function reconcileCases($app, &$caseList, $localServerCases) {
	// fix the caseList.
	$defaultServerClock = new VectorClock ( null );
	$defaultServerClock->setVersion ( $app ['deviceId'], 1 );
	$defaultJSONArrayServerClock = json_decode ( $defaultServerClock->getJSONClockString (), true );
	
	foreach ( $caseList as $i => &$row ) {
		$serverCase = isset ( $localServerCases, $localServerCases [$row ['id']] ) ? $localServerCases [$row ['id']] : null;
		if (isset ( $serverCase )) {
			$strJSONServerClock = $serverCase ['clock'];
			$serverClock = new VectorClock ( json_decode ( $strJSONServerClock, true ) );
			$clientClock = new VectorClock ( $row ['clock'] ); // the caselist row has decoded json array for the clock
			                                                   
			// compare clocks
			if ($clientClock->IsLessThan ( $serverClock )) {
				// Local server case is more recent, do not update
				// Remove this case from the $caseList.
				// echo 'client clock less than server clock';
				unset ( $caseList [$i] );
				continue;
			} else if ($serverClock->IsLessThan ( $clientClock )) {
				// Update is newer, replace the local server case
				// do nothing. $row in the caseList will update the server case. client clock will be updated on the server.
				// echo 'server clock less than client clock';
			} else if (! $serverClock->IsEqual ( $clientClock )) {
				// Conflict - neither clock is greater - always use the client case and merge the clocks
				// merge the clocks
				// echo 'conflict! ';
				$serverClock->merge ( $clientClock );
				// update the case using the merged clock
				$row ['clock'] = json_decode ( $serverClock->getJSONClockString (), true );
			}
		}
		if (count ( $row ['clock'] ) == 0) { // set the server default clock for updates or inserts if the clock sent is empty
			$row ['clock'] = $defaultJSONArrayServerClock;
		}
	}
	unset ( $row );
	// remove cases that have been discarded.
	$caseList = array_filter ( $caseList );
}
function prepareJSONForInsertOrUpdate($app, $dictName, &$caseList) {
	// for each row get the record list array to multi-line string for the questionnaire data
	// Get the clocks for the cases on the server.
	// get local server cases
	$localServerCases = getLocalServerCaseList ( $app, $dictName, $caseList );
	// reconcile server cases with the client
	reconcileCases ( $app, $caseList, $localServerCases );
	foreach ( $caseList as &$row ) {
		$row ['data'] = implode ( "\n", $row ['data'] );
		$row ['deleted'] = (1 == $row ['deleted']) ? true : false;
		$row ['verified'] = (1 == $row ['verified']) ? true : false;
		$row ['clock'] = json_encode ( $row ['clock'] ); // convert the json array clock to json string
	}
	unset ( $row );
}
function prepareResultSetForJSON(&$caseList) {
	// for each row get the record list array to multi-line string for the questionnaire data
	foreach ( $caseList as &$row ) {
		unset($row['revision']);
		$row ['data'] = preg_split ( '/$\R?^/m', $row ['data'] );
		$row ['deleted'] = (1 == $row ['deleted']) ? true : false;
		$row ['verified'] = (1 == $row ['verified']) ? true : false;
		if (isset ( $row ['partial_save_mode'] )) {
			$row ['partialSave'] = array (
					"mode" => $row ['partial_save_mode'],
					"field" => array (
							"name" => $row ['partial_save_field_name'],
							"levelKey" => $row ['partial_save_level_key'],
							"recordOccurrence" => intval ( $row ['partial_save_record_occurrence'] ),
							"itemOccurrence" => intval ( $row ['partial_save_item_occurrence'] ),
							"subitemOccurrence" => intval ( $row ['partial_save_subitem_occurrence'] ) 
					) 
			);
		} else {
			unset ( $row ['partialSave'] );
		}
		// unset partial_save_ ... columns
		unset ( $row ['partial_save_mode'] );
		unset ( $row ['partial_save_field_name'] );
		unset ( $row ['partial_save_level_key'] );
		unset ( $row ['partial_save_record_occurrence'] );
		unset ( $row ['partial_save_item_occurrence'] );
		unset ( $row ['partial_save_subitem_occurrence'] );
		
		if (empty ( $row ['clock'] ))
			$row ['clock'] = array ();
		else
			$row ['clock'] = json_decode ( $row ['clock'] );
		
		if (isset ( $row ['lastModified'] )) {
			$lastModifiedUTC = DateTime::createFromFormat ( 'Y-m-d H:i:s', $row ['lastModified'], new \DateTimeZone ( "UTC" ) );
			$row ['lastModified'] = $lastModifiedUTC->format ( DateTime::RFC3339 );
		}
	}
	unset ( $row );
}
function validateEncodedJSON($app, $data, $uri) {
	// Get the schema and data as objects
	$data = json_decode ( $data );
	validateDecodedJSON($app, $data, $uri);
}
function validateDecodedJSON($app, $data, $uri) {
	// Get the schema and data as objects
	$strMsg = "JSON does not validate. Violations:\n";
	if (null == $data) {
		$app->abort ( 404, $strMsg . json_last_error_msg () );
	}
	
	$schema  = null;
	$bFound  = false;
	if(extension_loaded('apcu') && ini_get('apc.enabled')){
		$bFound = false;
		$schema  = apc_fetch($uri, $bFound);
	}
	
	if($bFound == false){
		$retriever = new JsonSchema\Uri\UriRetriever ();
		$fullschema = $retriever->retrieve ( 'file://' . realpath ( __DIR__ . '/swagger.json' ) );
		
		// If you use $ref or if you are unsure, resolve those references here
		// This modifies the $schema object
		$refResolver = new JsonSchema\RefResolver ( $retriever );
		$refResolver->resolve ( $fullschema );
		
		$schema = $retriever->resolvePointer ( $fullschema, $uri );
		$refResolver->resolve ( $schema );

		//store the schema object for caching
		if(extension_loaded('apcu') && ini_get('apc.enabled')){
			apc_store($uri, $schema);
		}
	}
		// // Validate
	$validator = new JsonSchema\Validator ();
	$validator->check ( $data, $schema );

	if ($validator->isValid ()) {
		return;
	} else {
		foreach ( $validator->getErrors () as $error ) {
			$strMsg .= sprintf ( "[%s] %s\n", $error ['property'], $error ['message'] );
		}
		$app->abort ( 404, $strMsg );
	}
}
function dumpProfilerOutput($app) {
	if ($app ['debug'] == true) {
		$profiles = $pdo->getProfiler ()->getProfiles ();
		foreach ( $profiles as $key => $val ) {
			echo $profiles [$key] ['statement'];
			echo $profiles [$key] ['trace'];
			var_dump ( $profiles [$key] ['bind_values'] );
		}
	}
}
function tableExists($pdo, $table) {
	try {
		$result = $pdo->query ( "SELECT 1 FROM {$table} LIMIT 1" );
	} catch ( \Exception $e ) {
		return false;
	}
	
	// ALW - By default PDO will not throw exceptions, so check result also.
	return $result !== false;
}
function isValidUser($user, $add = true) {
	// return false if any of the required attributes are not set.
	if ($add === true) { // test the user attributes for add action
		$ret = ! (empty ( $user ['password'] ) || empty ( $user ['username'] ) || empty ( $user ['firstName'] ) || empty ( $user ['lastName'] ));
	} else { // for updating user empty password means ignore password update
		$ret = ! (empty ( $user ['username'] ) || empty ( $user ['firstName'] ) || empty ( $user ['lastName'] ));
	}
	return $ret;
}

/**
 * Get the column names for the individual case id columns in cases table.
 *
 * @param Dictionary $dict
 *        	CSPro dictionary
 * @return string[] List of column names
 *        
 */
function getCaseIdColumnNames($dict) {
	$levelOneIds = $dict->getLevels () [0]->getIdItems ();
	return array_map ( function ($i) {
		return 'id_' . $i->getName ();
	}, $levelOneIds );
}

/**
 * Get values for the case id columns for a case.
 *
 * @param Dictionary $dict
 *        	CSPro dictionary
 * @param string $questionnaire
 *        	Data for case in CSPro text format
 * @return array Array of values
 *        
 */
function getCaseIdColumnValues($dict, $questionnaire) {
	$levelOneIds = $dict->getLevels () [0]->getIdItems ();
	$dataParser = new \CSPro\Data\Parser ( $dict, $questionnaire );
	
	$result = array ();
	
	for($i = 0; $i < count ( $levelOneIds ); ++ $i) {
		$idItem = $levelOneIds [$i];
		$idVal = $dataParser->getItemValue ( $idItem->getName () );
		array_push ( $result, $idVal );
	}
	
	return $result;
}
