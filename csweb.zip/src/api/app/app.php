<?php
require_once __DIR__ .'/bootstrap.php';
require_once __DIR__ . '/config.php';
require __DIR__ .'/server.php';
require __DIR__ .'/version.php';

//http://php-and-symfony.matthiasnoback.nl/2012/01/silex-getting-your-project-structure-right/
use Aura\Sql\ExtendedPdo;
use Aura\Sql\Profiler;
use CSPro\CSProMySQLHandler;

//max in memory json limit in MB. if json body is greater than this number code uses streaming parser
//used for performance optimization at the expense of using memory
define('MAX_JSON_MEMORY_LIMIT', 5);
		
$app          = new Silex\Application();
//$app['start'] = microtime(true);

//$app['pdo'] = new ExtendedPdo('mysql:host=localhost;dbname=cspro', 'root', '');
$app['pdo'] = new ExtendedPdo('mysql:host='.DBHOST.';dbname='.DBNAME.';charset=utf8mb4', DBUSER, DBPASS);
$app['deviceId'] = SERVER_DEVICE_ID; //server name
$app['apiVersion'] = API_VERSION; // REST API version
$app['schemaVersion'] = SCHEMA_VERSION; // Database schema version

//debug settings. deactivate profiler for production
$app['pdo']->setProfiler(new Profiler);
$app['debug'] = false;
$app['server']=$server;
$app['oauth'] = ENABLE_OAUTH;
$app['files_folder']=FILES_FOLDER;

// Set default timezone to avoid warnings when using date/time functions
// and timezone not set in php.ini
date_default_timezone_set(DEFAULT_TIMEZONE);

//register logging service 
//Change loglevel to Monolog\Logger::DEBUG to troubleshoot 
$logLevel = Monolog\Logger::ERROR;	
$app->register(new Silex\Provider\MonologServiceProvider(), array(
    'monolog.logfile' => __DIR__.'/../../../logs/api.log',
	'monolog.name' => 'CSPro API',
	'monolog.level'=> $logLevel	
));

//Create MysqlHandler
//TOOD:  loglevel be in the config tables?
$mySQLHandler = new CSProMySQLHandler($app['pdo'], "cspro_log",array(), $logLevel);
$app['monolog']->pushHandler($mySQLHandler);
