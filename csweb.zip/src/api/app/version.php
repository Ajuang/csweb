<?php
define('API_VERSION', '1.1'); // REST API version, incremented when REST endpoints/arguments changes
define('SCHEMA_VERSION', 2); // Database schema version, incremented when database tables change
?>
