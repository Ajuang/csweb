<?php
use CSPro\CSProOAuthPdo;
//$dsn      = 'mysql:dbname=my_oauth2_db;host=localhost';
$dsn = 'mysql:host='.DBHOST.';dbname='.DBNAME.';charset=utf8mb4';

// error reporting (this is a demo, after all!)
ini_set('display_errors',1);error_reporting(E_ALL);

// Autoloading (composer is preferred, but for this example let's just do this)
//require_once('oauth2-server-php/src/OAuth2/Autoloader.php');
//OAuth2\Autoloader::register();

// $dsn is the Data Source Name for your database, for exmaple "mysql:dbname=my_oauth2_db;host=localhost"
$storage = new CSPro\CSProOAuthPdo(array('dsn' => $dsn, 'username' => DBUSER, 'password' => DBPASS));

// Pass a storage object or array of storage objects to the OAuth2 server class
$server = new OAuth2\Server($storage);

// Add the "User Credentials" grant type
$server->addGrantType(new OAuth2\GrantType\UserCredentials($storage));

// the refresh token grant request will have a "refresh_token" field
// with a new refresh token on each request
$grantType = new OAuth2\GrantType\RefreshToken($storage, array(
    'always_issue_new_refresh_token' => true,
    'refresh_token_lifetime'         => 2419200,
));

// add the grant type to your OAuth server
$server->addGrantType($grantType);
