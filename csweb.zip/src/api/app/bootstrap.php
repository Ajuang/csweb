<?php
require_once __DIR__ . '/../../../vendor/autoload.php';
use Symfony\Component\ClassLoader\UniversalClassLoader;
$app = new Silex\Application();

$loader = new UniversalClassLoader();
$loader->registerNamespace('CSPro', __DIR__.'/../src');
$loader->register();

return $loader;
