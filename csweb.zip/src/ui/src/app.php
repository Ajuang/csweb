<?php
require_once __DIR__ .'/bootstrap.php';


if (!file_exists(__DIR__ . '/config.php')) {
	header('HTTP/1.0 403 Forbidden');
	echo 'This application needs to be configured. Please run <a href="../setup/index.php">setup</a>';
	exit;
}

require_once __DIR__ . '/config.php';

use Silex\Application;
use Silex\Provider;
use Symfony\Component\HttpFoundation\Request;
use GuzzleHttp\Client;
use Controllers\DictionaryController;
use CSPro\HttpHelper;

//
// Application setup
//
$app = new Application();
$app->register(new Provider\UrlGeneratorServiceProvider());
$app->register(new Provider\TwigServiceProvider());

//set debug to true flag for debugging
$app['debug']=false;
//set the rest api url to the point to the correct site
$app['cspro_rest_api_url']=API_URL;

$app['twig.path'] = array(__DIR__.'/views');
$app['twig.options'] = array('cache' => __DIR__.'/../../../var/cache/twig','auto_reload'=>true);
$app['twig']->addGlobal('csproVersion', '7.1.3');
$app['twig']->addGlobal('apiUrl', $app['cspro_rest_api_url']);
$app["services.guzzle.client"] = function() {
    return ;
};

$app['services.httphelper'] = function ($app) {
	$guzzleClient = new Client(['http_errors' => false]);
	return new HttpHelper($guzzleClient,$app['cspro_rest_api_url'], $app['monolog']);
};

$app->boot();

// Controllers
//


$app->mount('/', new Controllers\LoginController());
$app->mount('/dashboard', new Controllers\DictionaryController());
$app->mount('/users', new Controllers\UserController());
$app->mount('/apps', new Controllers\AppController());

// Set default timezone to avoid warnings when using date/time functions
// and timezone not set in php.ini
date_default_timezone_set(DEFAULT_TIMEZONE);

//register logging service 
// TODO:  change the setting to  monolog.level to INFO  in production.
$app->register(new Silex\Provider\MonologServiceProvider(), array(
    'monolog.logfile' => __DIR__.'/../../../logs/ui.log',
	'monolog.name' => 'CSPro UI',
	'monolog.level'=> Monolog\Logger::ERROR
));

//add your routes before the return
return $app;
