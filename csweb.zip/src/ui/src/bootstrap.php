<?php
require_once __DIR__ . '/../../../vendor/autoload.php';
use Symfony\Component\ClassLoader\UniversalClassLoader;

$loader = new UniversalClassLoader();
//to register a namespace point to the directory that contains the folder with the same name as the namespace
$loader->registerNamespace('Controllers', __DIR__ .'/');
$loader->registerNamespace('CSPro', __DIR__.'/');
$loader->register();

return $loader;
