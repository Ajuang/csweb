<?php
namespace Controllers;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;

class UserController implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];
        $controllers->get('/', 'Controllers\UserController::viewUserListAction')->bind('users');
        $controllers->post('/', 'Controllers\UserController::addUserAction')->bind('add');
        $controllers->put('/{username}', 'Controllers\UserController::updateUserAction')->bind('update');
        $controllers->delete('/{username}', 'Controllers\UserController::deleteAction')->bind('delete');
		$controllers->before(function(Request $request, Application $app){
																					$accesss_token = "";
																					if( !$app['request']->cookies->has('access_token')){
																						return $app->redirect($app["url_generator"]->generate('login'));
																					}
																			  });
        return $controllers;
    }

	public function  viewUserListAction(Application $app)
	{
		$client = $app['services.httphelper'] ;
        	//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
        $response = $client->request('GET','users', null, ['Authorization' =>$authHeader,'Accept' => 'application/json']);

		//unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }
		$userlist=json_decode($response->getBody());
	    return $app['twig']->render('users.twig', array('userlist' => $userlist));
	}
   
   public function  addUserAction(Application $app, Request $request)
	{
		$client = $app['services.httphelper'] ;
        	//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;

        //get the json user info to add 
        $body = $request->getContent();
        
        //call the rest api to  add the user
        $response = $client->request('POST','users/', $body, ['Authorization' =>$authHeader, 'Content-Type'=>'application/json; charset=utf-8', 'Accept' => 'application/json']);																							//unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }
       //create a symfony response object to return
       $addUserResponse =  new Response($response->getBody(), $response->getStatusCode());
       $addUserResponse->headers->set('Content-Type',$response->getHeader('Content-Type'));
       return $addUserResponse;
	}

    public function  updateUserAction(Application $app, Request $request, $username)
	{
		$client = $app['services.httphelper'];
		
        //set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;

        //get the json user info to update 
        $body = $request->getContent();
        //call the rest api to  update the user
        $response = $client->request('PUT','users/'.$username, $body, ['Authorization' =>$authHeader]); 
       
       //create a symfony response object to return
       $updateUserResponse =  new Response($response->getBody(), $response->getStatusCode());
       $updateUserResponse->headers->set('Content-Type',$response->getHeader('Content-Type'));
       return $updateUserResponse;
	}
    
    public function deleteAction(Application $app, $username)
	{
        $client = $app['services.httphelper'] ;
        //set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
        $authHeader = 'Bearer ' .  $access_token;
        
        //call the rest-api to delete the user
        $response = $client->request('DELETE', 'users/' . $username, null, ['Authorization' =>$authHeader,'Accept' => 'application/json']);
      
        //create the symfony response for the delete action
		$deleteResponse =  new Response($response->getBody(), $response->getStatusCode());
		$deleteResponse->headers->set('Content-Type',$response->getHeader('Content-Type'));
		return $deleteResponse;
	}
}
