<?php
namespace Controllers;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;

class LoginController implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];
		$controllers->get('/', 'Controllers\LoginController::login');
        $controllers->get('/login', 'Controllers\LoginController::login')->bind('login');
		$controllers->post('/login_check', 'Controllers\LoginController::loginAction')->bind('login_check');
		$controllers->get('/logout', 'Controllers\LoginController::logoutAction')->bind('logout');
        return $controllers;
    }

	public function login(Application $app) {
		  if(!isset($app['login.lasterror'])) $app['login.lasterror'] ="";
		  if(!isset($app['login.last_username'])) $app['login.last_username'] ="";
		  return $app['twig']->render('login.twig', array(
								'error'         => $app['login.lasterror'],
								'last_username' => $app['login.last_username'],
								));
	}

	public function  loginAction(Application $app , Request $request)
	{
		$client = $app['services.httphelper'] ;
		$username = trim($_POST['_username']);
		$password = trim($_POST['_password']);
		$app['login.last_username'] =$username;
		$requestBody = json_encode(array("client_id"=>"cspro_android",
									  "client_secret"=>"cspro",
									  "grant_type"=>"password",
									   "username"=>$username,
									   "password"=>$password));
		$response = $client->request('POST', 'token', $requestBody, ['Content-Type' => 'application/json',
                                                                      'Accept' => 'application/json']);
	  
		$jsonResponse = json_decode($response->getBody(),true);

		//if the authentication failed.  redirect to the login page and set the lastError and the lastUserName 
		if(isset($jsonResponse['error_description'])){
			$app['login.lasterror'] =$jsonResponse['error_description'];
			return $this->login($app);
		} else if($response->getStatusCode() == 401 && isset($jsonResponse['message'])){
			$app['login.lasterror'] =$jsonResponse['message'];
			return $this->login($app);
		} else if($response->getStatusCode() == 200  && isset($jsonResponse['access_token'])){
			if(!$this->isUserAdmin($app, $jsonResponse['access_token'] , $username) ){
				return $this->login($app); //redirect ??
			}
			 //check if the access_token in available and then set the cookie 
			 //if it succeeds redirect to the targetpath with the cookie set correctly with the token.
			$response = new Response();
            $response->headers->setCookie(new Cookie("access_token", $jsonResponse['access_token']));
			$response->headers->setCookie(new Cookie("username", $username));
			$response->send();
			return $app->redirect(trim($_POST['_target_path']));
		}
        else {
			$app['monolog']->addDebug('Failed Authenticating  User. '  . $response->getBody());
			$app['login.lasterror'] = 'Failed to contact authentication server. Please contact your site administrator.';
			return $this->login($app); //redirect ??
		}
	
	}
	public function isUserAdmin(Application $app, $access_token , $username) 
	{
		$client = $app['services.httphelper'] ;
		$response = $client->request('GET', 'users/'.$username, null, ['Content-Type' => 'application/json',
																	'Authorization'=> 'Bearer ' . $access_token,
																	'Accept' => 'application/json']);
	 
		$jsonResponse = json_decode($response->getBody(),true);
		if(isset($jsonResponse['role']) &&  $jsonResponse['role'] == '2'){
			return true;
		}
		else if ($jsonResponse['status'] == 500) {
			$app['login.lasterror'] = 'Login failed. ' . $jsonResponse['message'];
		}
		else{
			$app['login.lasterror'] = 'Login failed. Insufficient privileges.';
		}
		return false;
	}

	public function logoutAction(Application $app) {
	 $app['login.lasterror'] ="";
	 $app['login.last_username'] ="";
     $response = new Response();
     $response->headers->clearCookie('access_token');
     $response->headers->clearCookie('username');
     $response->send();
	 return $app->redirect('login');
	
	}
  
}
