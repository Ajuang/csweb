<?php
namespace Controllers;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;

class DictionaryController implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        // creates a new controller based on the default route
        $controllers = $app['controllers_factory'];
        $controllers->get('/', 'Controllers\DictionaryController::dashboardAction')->bind('dashboard');
		$controllers->post('/dictionaries', 'Controllers\DictionaryController::uploadAction')->bind('upload');
		$controllers->get('/dictionaries/{dictname}', 'Controllers\DictionaryController::downloadAction')->bind('downloadDictionary');
		$controllers->delete('/dictionaries/{dictname}', 'Controllers\DictionaryController::deleteAction')->bind('deleteDictionary');

		$controllers->before(function(Request $request, Application $app){
																					$accesss_token = "";
																					if( !$app['request']->cookies->has('access_token')){
																							return $app->redirect($app["url_generator"]->generate('login'));
																					}
																			  });
        return $controllers;
    }
	
	public function  dashboardAction(Application $app)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		$dictionariesEndpoint = $app['cspro_rest_api_url'].'dictionaries/';
        $response = $client->request('GET', 'dictionaries/', null, ['Authorization' =>$authHeader, 'Accept' => 'application/json']);
		
        //unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }
		$dictionaries=json_decode($response->getBody());
		return $app['twig']->render('data.twig', array('dictionaries' => $dictionaries));
	}
	public function  downloadAction(Application $app , $dictname)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		//download the data
        $response =$client->request('GET', 'dictionaries/'.$dictname .'/syncspec', null, ['Authorization' =>$authHeader,'Accept' => 'application/json']);

		//unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }
        
        $downloadResponse =  new Response($response->getBody(), $response->getStatusCode());
		$downloadResponse->headers->set('Content-Disposition', $response->getHeader('Content-Disposition')[0]);
		return $downloadResponse;
	}
	public function  uploadAction(Application $app, Request $request)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		
		//get the json user info to add 
        $body = $request->getContent();
		
		//upload dictionary
        $response =$client->request('POST','dictionaries/', $body, ['Authorization' =>$authHeader,'Content-Type'=>'application/json; charset=utf-8']);

		//unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }

		//create a symfony response object to return
        $uploadResponse =  new Response($response->getBody(), $response->getStatusCode());
		$uploadResponse->headers->set('Content-Type',$response->getHeader('Content-Type'));
		return $uploadResponse;
	}
	public function  deleteAction(Application $app , $dictname)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		//download the data
		$response =$client->request('DELETE','dictionaries/'.$dictname, null, ['Authorization' =>$authHeader,'Accept' => 'application/json']);

		//unauthorized or expired  redirect to logout page
		if($response->getStatusCode() == 401) {
			return $app->redirect($app["url_generator"]->generate('logout'));
		}
	
			//create a symfony response object to return
        $deleteResponse =  new Response($response->getBody(), $response->getStatusCode());
		$deleteResponse->headers->set('Content-Type',$response->getHeader('Content-Type'));
		return $deleteResponse;
	}
}