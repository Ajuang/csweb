<?php
namespace Controllers;
use Silex\Application;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Silex\ControllerProviderInterface;

class AppController implements ControllerProviderInterface
{
    public function connect(Application $app)
    {
        $controllers = $app['controllers_factory'];
        $controllers->get('/', 'Controllers\AppController::viewAppListAction')->bind('apps');
		$controllers->get('/{appname}', 'Controllers\AppController::downloadAction')->bind('downloadApp');
        $controllers->delete('/{appname}', 'Controllers\AppController::deleteAction')->bind('deleteApp');
		$controllers->before(function(Request $request, Application $app){
																					$accesss_token = "";
																					if( !$app['request']->cookies->has('access_token')){
																						return $app->redirect($app["url_generator"]->generate('login'));
																					}
																			  });
        return $controllers;
    }
	
	public function viewAppListAction(Application $app)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		$appsEndpoint = $app['cspro_rest_api_url'].'apps/';
        $response = $client->request('GET', 'apps/', null, ['Authorization' =>$authHeader, 'Accept' => 'application/json']);
		
        //unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }
		$apps=json_decode($response->getBody());
		return $app['twig']->render('apps.twig', array('apps' => $apps));
	}

	public function downloadAction(Application $app , $appname)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		//download the data
        $response =$client->request('GET', 'apps/'.$appname , null, ['Authorization' =>$authHeader,'Accept' => 'application/octet-stream']);

		//unauthorized or expired  redirect to logout page
        if($response->getStatusCode() == 401) {
            return $app->redirect($app["url_generator"]->generate('logout'));
        }
        
        $downloadResponse =  new Response($response->getBody(), $response->getStatusCode());
		$downloadResponse->headers->set('Content-Disposition', $response->getHeader('Content-Disposition')[0]);
		return $downloadResponse;
	}

	public function  deleteAction(Application $app , $appname)
	{
		$client = $app['services.httphelper'] ;
		//set the oauth token
		$access_token = $app['request']->cookies->has('access_token') ? $app['request']->cookies->get('access_token')  :  "" ;
		$authHeader = 'Bearer ' .  $access_token;
		//download the data
		$response =$client->request('DELETE','apps/'.$appname, null, ['Authorization' =>$authHeader,'Accept' => 'application/json']);

		//unauthorized or expired  redirect to logout page
		if($response->getStatusCode() == 401) {
			return $app->redirect($app["url_generator"]->generate('logout'));
		}
	
		//create a symfony response object to return
        $deleteResponse =  new Response($response->getBody(), $response->getStatusCode());
		$deleteResponse->headers->set('Content-Type',$response->getHeader('Content-Type'));
		return $deleteResponse;
	}
}