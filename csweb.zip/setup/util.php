<?php

define ("API_SRC_DIRECTORY", '/../src/api/app/');
define ("API_CONFIG_FILE_RELATIVE_PATH", API_SRC_DIRECTORY . 'config.php');
define ("API_VERSION_FILE_RELATIVE_PATH", API_SRC_DIRECTORY . 'version.php');
define ("UI_CONFIG_FILE_RELATIVE_PATH", '/../src/ui/src/config.php');

function getApiConfigFilePath()
{
	return __DIR__ . API_CONFIG_FILE_RELATIVE_PATH;
}

function getUiConfigFilePath()
{
	return __DIR__ . UI_CONFIG_FILE_RELATIVE_PATH;
}

function alreadyConfigured()
{
	return file_exists(getApiConfigFilePath()) &&
		file_exists(getUiConfigFilePath());
}

function getApiVersionFilePath()
{
	return __DIR__ . API_VERSION_FILE_RELATIVE_PATH;
}

?>
