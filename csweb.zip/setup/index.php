<?php
$rewriteSuccess = false;

require_once __DIR__ .'/prereqs.php';

?>
