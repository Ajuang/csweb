<?php 
$app = require __DIR__.'/../src/ui/src/app.php';
//require __DIR__.'/../config/prod.php';
$app->run();
